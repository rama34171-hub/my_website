function addToCart(productName) {
    alert('تم إضافة ' + productName + ' إلى السلة!');
}
